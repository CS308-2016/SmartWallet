package com.togather.me.smartwallet;

/**
 * Created by mouli on 8/15/15.
 */
public interface InterfaceUtils {
    public abstract void onBtnClick(int position, String value);
}