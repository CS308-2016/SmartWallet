Project Name:

Team Members:
+   Shivam Garg (12D020036) 
+   Mihir Kulkarni (12D020007)
+   Aditya Nambiar (12D070012)
+   Siddhartha Dutta (120040005)

Project Description:

We spend and receive money from our wallets all the time, be it bank accounts, lending to or borrowing from friends, spending at outings, or whatever else. Keeping track of all of these is hard, and oftentimes, we’re left wondering where we’ve spent and borrowed all our money at the end of the month.

The Smart Wallet is the solution to this problem. It is a plug and play device for your wallet which will help you keep a record of your cash flow transactions, allowing you to analyse how your spending and lending patterns vary with time and location.

Furthermore, it can act as a calculator when you need to do fast calculations while making any transactions. Moreover, it also has a theft detection system which will send you an alert on your mobile if your wallet is stolen.
